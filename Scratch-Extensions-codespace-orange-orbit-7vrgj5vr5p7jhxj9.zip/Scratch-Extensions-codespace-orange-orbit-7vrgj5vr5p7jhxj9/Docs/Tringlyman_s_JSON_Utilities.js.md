# Tringlyman's JSON Utilities Documents


Welcome to the extension based on the JS programming and the console of the currently visited website! <sub>(press F12 to see it!)</sub>

---

|name|type|description|
|---|---|---|
|alert box|Block|It will send a message on the screen<br>The messege will be a text of your choice<br>Others:<br>Prompt:<br>Same as Alert but you can insert an input!|
|Log Box|block|This will send a message of your liking in the console of the website<br>Other:<br>Warn and Error:<br>Visual differences in console|
|Question Peformer|Hat Block|After a prompt block is used it will trigger this hat block|
|Answer Provider|Reporter|This reporter will return as value the last answer in a prompt block|
|Answer Checker|Boolean|This block is changing the latest answer from a prompt block to nothing<br>If custom reset is true then you can set custom reset to anything and it actually reset answer to that!|
